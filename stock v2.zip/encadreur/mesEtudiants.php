<html>
<?php include("../config/db.php"); ?>
<?php include("layouts/head.php"); ?>
<body>
    <?php include("layouts/navbar.php") ?>
    <div class="container-fluid">
    <div class="col-md-3 col-xs-12">
                <!-- load profile ticket : name email number .. ect -->
                <div class="row well">
                <?php include("layouts/profileTicket.php"); ?>
                </div>
                     <!-- load sidebar Menu  -->
                    
                     <?php include("layouts/sidebar.php"); ?>
        </div>

    <div class="col-md-9 col-xs-12 ">
        <div class="container-fluid">
            <h2><b id="liste des mes etudiantsME">Liste De Mes Etudiants : </b></h2>
            <br><br>
        <div class="table-responsive">
        <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th id="idME">ID</th>
                <th id="PseudoME">Pseudo</th>
                <th id="sujetME">Sujet</th>
                <th id="tauxAvancementME">Taux d'avancement</th>
                
        
            </tr>
        </thead>
        <tbody>
        <?php 
          $user = $_SESSION['user'];
          $query = "SELECT * FROM `sujet` WHERE `encadreur`=? AND `etat`= ? ";
          $sql = $pdo->prepare($query);
          $sql->execute([$user,1]);
          
          if($sql->rowCount()>0){
              
              while($result = $sql->fetch(PDO::FETCH_ASSOC)){
                $query2 = "SELECT * FROM `compte_etudiants` WHERE `sujet`=? ";
                $sql2 = $pdo->prepare($query2);
                $sql2->execute([$result['titre']]);
                $result2 = $sql2->fetch(PDO::FETCH_ASSOC);
        
        ?>
            <tr>
                <td><?php echo $result2['idCompte']; ?></td>
                <td>
                <a href="profile.php?user=<?php echo $result2['user']; ?>"><?php echo $result2['user']; ?> </a>
                </td>
                <td>
                <a href="theme.php?id=<?php echo $result['id'];?>"> <?php echo $result['titre']; ?></a>    
               </td>
                <td><?php echo $result['tauxAvancement']; ?> %</td>
              
              
            </tr>
              <?php 
                }
            }
             ?>

        </tbody>
       
    </table>

        </div>
                </div>

    </div>
 

    </div>

<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
</body>
</html>