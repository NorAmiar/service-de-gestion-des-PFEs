<?php 
    include("../config/db.php");
    $id="";
    if(isset($_GET['id'])){
        $id = $_GET['id'];
    }
 
?>

<!DOCTYPE html>
<html>
<?php include("layouts/head.php"); ?>
<body>
    <?php include("layouts/navbar.php") ?>
    <div class="container-fluid">
    <div class="col-md-3 col-xs-12">
                <!-- load profile ticket : name email number .. ect -->
                <div class="row well">
                <?php include("layouts/profileTicket.php"); ?>
                </div>
                     <!-- load sidebar Menu  -->
                    
                     <?php include("layouts/sidebar.php"); ?>
        </div>
            <div class="col-md-9 col-xs-12 ">
                <center><h2>Détail de message</h2></center>
                <?php   
                
                   $departement = $_SESSION['departement'];
                    $query = "SELECT * FROM `messagerie` WHERE `id`=?";
                    $sql = $pdo->prepare($query);
                    $sql->execute([$id]);
                    if($sql->rowCount()==1){
                        $result = $sql->fetch(PDO::FETCH_ASSOC);
                       
                        if($result['recepteur']==$_SESSION['user']){
                            $now = date("Y-m-d H:i:s");
                            $query1 = "UPDATE `messagerie` SET `statut`=?,`date_vue`=? WHERE `id`=?  AND `departement`=?";
                            $sql1 = $pdo->prepare($query1);
                            $sql1->execute([1,$now,$id,$departement]);
                        }
                        ?>
                        <p><b>Expiditeur : </b><?php echo $result['expiditeur']; ?></p>
                        <p><b>Role : </b><?php echo $result['natureExp']; ?></p>
                        <p><b>Recepteur : </b><?php echo $result['recepteur']; ?></p>
                        <p><b>Role : </b><?php echo $result['natureRec']; ?></p>
                        <p><b>Date : </b><?php echo $result['date']; ?></p>
                        <p><b>Objet : </b><?php echo $result['objet']; ?></p>
                        <p><b>Contenu : </b><?php echo $result['contenu']; ?></p>
                        <p><b>Etat : </b><?php if($result['statut']==0){
                            echo "Non vue";
                        }else{
                            if($result['statut']==1){
                                echo "Vue";
                            }
                        } ?></p>
                        <p><b>Date de vue : </b><?php echo $result['date_vue']; ?></p>
                        
                        
                        <?php
                    }
                ?>
            
            </div>

            
        </div>

        
        <script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
    </body>
    </html>