<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header" style="text-align:center;">
      <a class="navbar-brand"  id="brand" href="index.php">ESPACE ADMINISTRATEUR</a>
    </div>

   <ul class="nav navbar-nav navbar-right">
   <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" id="lang">LANGUE <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a id="fr" href="#"><i><img src="../static/images/fr.png" alt="fr" height="30px"> </i> FR</a></li>
                                <li><a id="eng" href="#"><i><img src="../static/images/en.png" alt="en" height="30px"> </i> EN</a></li>
                                <li><a id="ar" href="#"><i><img src="../static/images/ar.png" alt="ar" height="30px"> </i> AR</a></li>
                            </ul>
                            </li>
    <li><a id="deco" href="deconnexion.php">Déconnexion</a></li>
   </ul>

  </div>
 
</nav>
