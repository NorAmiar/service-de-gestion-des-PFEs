<?php 
session_start();
    include("../config/db.php");
    $id= "";
 if(!empty($_GET['id']))
 {
    $id = $_GET['id'];
 }
?>
<html>
<html>
    <head>
	    <title>Gestion des PFEs | Université 8 Mai 1945 Guelma</title>
	    <meta charset="UTF-8">  
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        <link rel="stylesheet" href="../static/css/w3.css">
        <link rel="stylesheet" href="../static/css/admin.css">
        <link href="../static/css/bootstrap.min.css" rel="stylesheet">
        <script src="../static/js/jquery.js" ></script>
        <script src="../static/js/datatables.min.js"></script>
        <script src="../static/js/multi.min.js" ></script>
        <script src="../static/js/bootstrap.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
        <script src="../static/js/bar.js"></script>
    
        <link rel="stylesheet" href="../static/css/datatables.min.css">
     
    </head>
    <?php 
       if(isset($_SESSION['role']) && $_SESSION['role']=="admin"){
    
    ?>
    <body style="background-color:#e5ebf0;">
    <?php include("layouts/navbar.php"); ?>
        <br>
        <div class="container-fluid">
        <?php include("layouts/sidebar.php"); ?>
    <div class="col-md-9 col-xs-12 ">
        <div class="container-fluid">
            <?php  
                $query = "SELECT * FROM `sujet` WHERE `id`=?";
                $sql= $pdo->prepare($query);
                $sql->execute([$id]);
                $result = $sql->fetch(PDO::FETCH_ASSOC);
            ?>
        <center><h1><?php echo $result['titre'] ?></h1></center>
        <p><b>Encadreur : <a href="encadreur.php?user=<?php echo $result['encadreur'];?>"><?php echo $result['encadreur'];?></a>  </b> </p>  
        <p><b>Descreption : </b></p><br><center> <p><?php echo $result['contenu'];?></p></center>
        <p><b>Keywords : </b><?php echo $result['keywords'];?></p>
        <p><b>Environement : </b><?php echo $result['environement'];?></p>
        <p><b>Bibliographie : </b><?php echo $result['bibliographie'];?></p>
        <?php  if($result['valid']==0){
            ?>
            <p><b>Le theme n'est pas encore validé</b></p>
            <?php
        }else{
            if($result['valid']==1 && $result['etat']==1){
                $titre = $result['titre'];
                $query2 = "SELECT * FROM `compte_etudiants` WHERE `sujet`=?";
                $sql2 = $pdo->prepare($query2);
                $sql2->execute([$titre]);
                $result2 = $sql2->fetch(PDO::FETCH_ASSOC);

                
                ?> 
                
                 <p><b>Etudiant(s) : </b><a href="profile.php?user=<?php echo $result2['user']; ?>"><?php echo $result2['user']; ?></a></p>
                <p><b>Taux d'avancement :</b> <?php echo $result['tauxAvancement']; ?> </p>
                 <?php 
            }else{
                if($result['valid']==1 && $result['etat']==0){
                    ?> 
                    <p><b>Le theme n'est pas encore affecté</b></p>
                    <p><b>Nombre de fois choisi : </b> <?php echo $result['nb_choix']; ?> </p>
                    <?php
                }
            }
        } ?>
    

                </div>

    </div>

    </div>


</body>
<?php 
     }else{
         
    
    ?>
<script>
    window.alert("Something Wrong .. ? ");
    document.location.href = "../index.php";
</script>
        <?php 
        
     }
        ?>
</html>