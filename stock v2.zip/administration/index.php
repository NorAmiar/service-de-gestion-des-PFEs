<?php 
    session_start();
   //titre de page 
    $title = "ESPACE ADMIN";
?>

<!DOCTYPE html>
<html>
<!--  importation partie head -->
<?php include("layouts/head.php"); ?>

    <body>
    <?php 
        //si le visiteur est connecté et il s'agit d'un admin 
       if(isset($_SESSION['role']) && $_SESSION['role']=="admin"){
    
    ?>
    <?php 
    //import de la barre de navigation 
    include("layouts/navbar.php"); ?>
    <br><br>
    <div class="container-fluid">
    <?php 
    //import de menu lateral sidebar
    include("layouts/sidebar.php"); ?>
        
        <div class="col-md-9 col-xs-12">
       
        <!--  contenu de la page carte admin -->
            <div class="well" >
                <div align="center">
                  <b><span class="glyphicon glyphicon-user"></span> </b>  <b id="admin">Administrateur</b>

                    <br><br>
                    <p><b id="dep">Departement : </b> <?php echo $_SESSION['departement']; ?> </p>
                    <p><b id="date" > Date :</b> <?php echo date("d/m/Y"); ?></p>
                    <p><b id="heure">Heure :</b> <?php echo date("H:i"); ?> </p>
                    <a class="btn " id="settings" href="settings.php">Paramètres</a> 
                </div>
            </div>
        
        </div>
    </div>
   <script> 
   // gestion de button de la langue 
          $("#fr").click(function(){
            $.MultiLanguage("index.json","fr");
        });
        $("#eng").click(function(){
            $.MultiLanguage("index.json","en");
        });
        $("#ar").click(function(){
            $.MultiLanguage("index.json","ar");
        });
   </script>
    <?php 
     }else{
         
    
    ?>
<script>
    window.alert("Something Wrong .. ? ");
    document.location.href = "../index.php";
</script>
        <?php 
        
     }
        ?>
   
        </body>
    </html>
   