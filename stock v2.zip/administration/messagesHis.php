<?php 
    include("../config/db.php");
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>
	    <title>Gestion des PFEs | Université 8 Mai 1945 Guelma</title>
	    <meta charset="UTF-8">  
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        <link rel="stylesheet" href="../static/css/w3.css">
        <link rel="stylesheet" href="../static/css/admin.css">
        <link href="../static/css/bootstrap.min.css" rel="stylesheet">
        <script src="../static/js/jquery.js" ></script>
        <script src="../static/js/datatables.min.js"></script>
        <script src="../static/js/multi.min.js" ></script>
        <script src="../static/js/bootstrap.min.js"></script>
    
        <link rel="stylesheet" href="../static/css/datatables.min.css">
     
    </head>
    <?php 
       if(isset($_SESSION['role']) && $_SESSION['role']=="admin"){
    
    ?>
    <body style="background-color:#e5ebf0;">
    <?php include("layouts/navbar.php"); ?>
        <br>
    
        <div class="container-fluid">
        <?php include("layouts/sidebar.php"); ?>
            <div class="col-md-9 col-xs-12 " style="color:white;">
            <div class="table-responsive ">
                 <table id="example" class="table table-striped table-bordered" style="width:100%">
                     <thead>
                <tr>
                    <th>ID</th>
                    <th>Expiditeur</th>
                    <th>Nature Expiditeur</th>
                    <th>Recepteur</th>
                    <th>Nature Recepteur</th>
                    <th>Date</th>
                    <th>Statut</th>
                    <th>Date de vue</th>
            
                </tr>
        </thead>
        <tbody>
        <?php 
          $departement = $_SESSION['departement'];
          $query = "SELECT * FROM `messagerie` WHERE `departement`=? ";
          $sql = $pdo->prepare($query);
          $sql->execute([$departement]);
          
          if($sql->rowCount()>0){
              
              while($result = $sql->fetch(PDO::FETCH_ASSOC)){
        
        ?>



            <tr>
                <td><?php echo $result['id'];?> </td>
                <td><?php echo $result['expiditeur']; ?></td>
                <td><?php echo $result['natureExp']; ?></td>
                <td><?php echo $result['recepteur']; ?></td>
                <td><?php echo $result['natureRec']; ?></td>
                <td><?php echo $result['date']; ?></td>
                <td><?php echo $result['statut']; ?></td>
                <td><?php echo $result['date_vue']; ?></td>
            </tr>
            <?php   
                    }
                }
        ?>
        </tbody>
       
    </table>

        </div>
            </div>

            
        </div>

        
        <script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>
    </body>
    <?php 
     }else{
         
    
    ?>
<script>
    window.alert("Something Wrong .. ? ");
    document.location.href = "../index.php";
</script>
        <?php 
        
     }
        ?>
    </html>