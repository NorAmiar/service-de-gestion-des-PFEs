<?php

session_start(); 
include_once("../config/db.php");
require('../libs/alphapdf.php');

require('../libs/code128.php');

$pdf = new AlphaPDF();

//$m=$_SESSION['email'];

//extract data from database






//$header = array('nom11'=>'nom11' ,'nom22'=>'nom22', 'nom33'=>'nom33', 'nom111'=>'nom111', 'nonom222m2'=>'nom222', 'choix'=>'choix', 'TypeS'=>'TypeS', 'email2'=>'email2');

// while($row = mysqli_fetch_array($result)) { 
// $nom11=$row["nom11"];
// $nom22=$row["nom22"];
// $nom33=$row["nom33"];

// $nom111=$row["nom111"];
// $nom222=$row["nom222"];


// $choix=$row["choix"];
// $TypeS=$row["TypeS"];

// $email2=$row["email2"];


$pdf->AddPage('L');
$pdf->SetLineWidth(1.5);

// draw jpeg image
$pdf->Image('fAttribution.png',0,0,300);

// restore full opacity
$pdf->SetAlpha(1);


// draw jpeg image
$pdf->Image('fAttribution.png',0,0,300);

// restore full opacity
$pdf->SetAlpha(1);

// print name of supervisor
$pdf->SetFont('Arial', '', 14);
$pdf->Text(80,111,"ahmed");

// print date
$pdf->SetFont('Arial', '', 14);
$pdf->Text(80,121,"nour");

// print names of students
$pdf->SetFont('Arial', '', 14);
$pdf->Text(113,132,"badji".' '."amiar");

// print title of subject
$pdf->SetFont('Arial', '', 14);
$pdf->Text(55,144,"ok");



//}







$pdf->Output(); 
?>
