<?php 
    include("../config/db.php");
?>

<html>
<?php include("layouts/head.php"); ?>
<body>
    <?php include("layouts/navbar.php") ?>
    <div class="container-fluid">
    <div class="col-md-3 col-xs-12 ">
        <div class="row well">
        <?php include("layouts/profileTicket.php"); ?>
        </div>
        <?php include("layouts/sidebar.php"); ?>
        </div>
           

    <div class="col-md-9 col-xs-12 ">
        <div class="container-fluid well">
            <h2><b id="liste des themes ">Liste Des Themes : </b></h2>
            <?php 
                $query = "SELECT * FROM `departement` WHERE `nom`=?";
                $sql = $pdo->prepare($query);
                $sql->execute([$_SESSION['departement']]);
                if($sql->rowCount()==1){
                    $result = $sql->fetch(PDO::FETCH_ASSOC);
                    if($result['choixSujet']==1){
            ?>
        <div class="table-responsive">
        <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th id="idt">ID</th>
                <th id="titret">Titre</th>
                <th id="encadreurt">Encadreur</th>
                <th id="nombre de selectiont">Nombre de selection</th>
                <th id="actiont">Action</th>
        
            </tr>
        </thead>
        <tbody>
        <?php 
        $niveau=$_SESSION['niveau'];
            $query = "SELECT * FROM `sujet` WHERE `etat`=? AND `valid`=? AND `departement`=? AND `niveau`=?";
            $sql = $pdo->prepare($query);
            $sql->execute([0,1,$_SESSION['departement'],$niveau]);

            if($sql->rowCount()>0){
                while($result= $sql->fetch(PDO::FETCH_ASSOC)){

           
        ?>
            <tr>
                <td><?php echo $result['id']; ?></td>
                <td><a href="theme.php?id=<?php echo $result['id']; ?>"><?php echo $result['titre']; ?></a></td>
                <td><a href="encadreur.php?user=<?php echo $result['encadreur']; ?>"><?php echo $result['encadreur']; ?></a></td>
                <td><?php echo $result['nb_choix']; ?></td>
                <td><button onclick="choisir ('<?php echo $result['titre']; ?>')" id="choisirt">Choisir</button></td>
              
            </tr>
                    <?php 
                         }
                        }
                    
                    ?>

        </tbody>

    </table>

        </div>
        <?php 
                    }else{
                        echo "Session de choix des sujets est fermé";
                    }
                }
        ?>
                </div>

    </div>
  

    </div>

<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );

    function choisir(titre){
        $.post("process/choisir.php",{titre:titre},function(data){
            window.alert(data);
            location.reload();
        });
    }




</script>
</body>
</html>