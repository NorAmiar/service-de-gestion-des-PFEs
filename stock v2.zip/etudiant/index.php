<?php 
include("../config/db.php");
?>

<!DOCTYPE html>
<html>
    <?php include("layouts/head.php"); ?>
    <body>
    <?php include("layouts/navbar.php"); ?>


        <div class="container-fluid">
        
        <div class="col-md-3 col-xs-12 ">
        <div class="row well">
        <?php include("layouts/profileTicket.php"); ?>
        </div>
        <?php include("layouts/sidebar.php"); ?>
        </div>
           
            <div class="col-md-9 col-xs-12">
                <div class="container-fluid ">
                <div class="row well">
                    <div align="center">
                        <h2> <b id="bienvenue dans votre espaceE"> Bienvenue Dans Votre Espace</b></h2>
                        <?php 
                            $query = "SELECT * FROM `etudiant` WHERE `id_compte`=?";
                            $sql = $pdo->prepare($query);
                            $sql->execute([$_SESSION['id']]);
                            if($sql->rowCount()>0){
                          
                                while($result = $sql->fetch(PDO::FETCH_ASSOC)){
                        ?>
                        <h4><b id="moyenne de">Moyenne de <?php echo $result['nom']; ?>: </b><?php echo $result['moyenne_e']; ?></h4>
                       <?php 
                                }
                            }
                       ?>
                    </div>
                    <?php  
                   
                        if(!empty($_SESSION['theme'])){
                            $theme = $_SESSION['theme'];
                            $query = "SELECT * FROM `sujet` WHERE `titre`=?";
                            $sql = $pdo->prepare($query);
                            $sql->execute([$theme]);
                            $result = $sql->fetch(PDO::FETCH_ASSOC);
                            $keywords = $result['keywords'];
                            $keywords = explode(",",$keywords);
                            ?>
                             <h4><b id="themes avec mot clé">Themes Avec mot clé  <?php echo $keywords[0]; ?> : </b></h4>
                                <ul>
                                <?php 
                                    $query1 = "SELECT * FROM `sujet` WHERE NOT `titre`=?";
                                    $sql1 = $pdo->prepare($query1);
                                    $sql1->execute([$theme]);

                                    if($sql1->rowCount()>0){
                                        while($result1 = $sql1->fetch(PDO::FETCH_ASSOC)){
                                            $testKeywords = $result1['keywords'];
                                            $testKeywords = explode(",",$testKeywords);
                                            if(in_array($keywords[0],$testKeywords)){

                                           
                                  
                                ?>
                                    <li><a href="theme.php?id=<?php echo $result1['id'];?>"> <?php echo $result1['titre']; ?></a>    </li>
                                  <?php
                                   }
                                        }
                                    }
                                  ?>
                                </ul>
                                    <?php if(sizeof($keywords)>1){

                                     ?>
                                <h4><b id="themes avec mot cléE">Themes Avec mot clé  <?php echo $keywords[1]; ?> : </b></h4>
                                <ul>
                                <?php 
                                    $query1 = "SELECT * FROM `sujet` WHERE NOT `titre`=?";
                                    $sql1 = $pdo->prepare($query1);
                                    $sql1->execute([$theme]);

                                    if($sql1->rowCount()>0){
                                        while($result1 = $sql1->fetch(PDO::FETCH_ASSOC)){
                                            $testKeywords = $result1['keywords'];
                                            $testKeywords = explode(",",$testKeywords);
                                            if(in_array($keywords[1],$testKeywords)){

                                           
                                  
                                ?>
                                    <li><a href="theme.php?id=<?php echo $result1['id'];?>"> <?php echo $result1['titre']; ?></a>    </li>
                                  <?php
                                   }
                                        }
                                    }
                                  ?>
                                </ul>
                              
                            
                            <?php
                            }
                        }
                    ?>
                   
                </div>
             
                <div class="row well">
                    <div align="center">
                        <h2> <b id="Notifications"> Notifications : </b></h2>
                    </div>
                </div>
            </div>
            </div>
    
    </body>
    </html>