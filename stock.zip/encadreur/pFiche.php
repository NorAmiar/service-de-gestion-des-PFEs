<?php
include_once("pconnection.php");
require('alphapdf.php');

$pdf = new AlphaPDF();




$db = new dbObj();
$connString =  $db->getConnstring();
 
$result = mysqli_query($connString, "SELECT nom, prenom, sujet, nom1, nom2, nom3, date, c, acc, q, av, r, p, au FROM gst WHERE idG={$_GET['idG']} ") or die("database error:". mysqli_error($connString));
$header = array('nom'=>'nom' ,'prenom'=>'prenom', 'sujet'=>'sujet', 'nom1'=>'nom1', 'nom2'=>'nom2', 'nom3'=>'nom3', 'date'=>'date', 'c'=>'c', 'acc'=>'acc', 'q'=>'q', 'av'=>'av', 'r'=>'r', 'p'=>'p', 'au'=>'au');

while($row = mysqli_fetch_array($result)) { 
$nom=$row["nom"];
$prenom=$row["prenom"];
$sujet=$row["sujet"];
$nom1=$row["nom1"];
$nom2=$row["nom2"];
$nom3=$row["nom3"];

$date=$row["date"];
$c=$row["c"];
$acc=$row["acc"];
$q=$row["q"];
$av=$row["av"];
$r=$row["r"];
$p=$row["p"];
$au=$row["au"];

$pdf->AddPage();
$pdf->SetLineWidth(1.5);

// draw jpeg image
$pdf->Image('images/fiche.png',0,0,200);

// restore full opacity
$pdf->SetAlpha(1);


// draw jpeg image
$pdf->Image('images/fiche.png',0,0,200);

// restore full opacity
$pdf->SetAlpha(1);

// print name of supervisor
$pdf->SetFont('Arial', '', 12);
$pdf->Text(52,45,$nom.' '.$prenom);

// print date
$pdf->SetFont('Arial', '', 12);
$pdf->Text(52,57,$date);

// print title of subject
$pdf->SetFont('Arial', '', 12);
$pdf->Text(52,71,$sujet);

// print names of students
$pdf->SetFont('Arial', '', 12);
$pdf->Text(52,83.5,$nom1.', '.$nom2.', '.$nom3);


// print pourcentage
$pdf->SetFont('Arial', '', 14);
$pdf->Text(140,113,$c.' %');
$pdf->Text(140,126,$acc.' %');
$pdf->Text(140,139,$q.' %');
$pdf->Text(140,153,$av.' %');
$pdf->Text(140,165,$r.' %');
$pdf->Text(140,175,$p.' %');
$pdf->SetFont('Arial', '', 12);
$pdf->SetY(190);
$pdf->SetX(60);
$pdf->MultiCell(130, 7, $au, 3);

//$pdf->MultiCell( 190, 7, $au, 1);




}

$pdf->Output();
?>
