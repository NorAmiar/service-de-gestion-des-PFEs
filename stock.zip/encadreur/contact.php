<html>
    <?php  
        include("../config/db.php");
     
    ?>
<?php include("layouts/head.php"); ?>
<body>
    <?php include("layouts/navbar.php") ?>
    <div class="container-fluid">
    <div class="col-md-3 col-xs-12">
                <!-- load profile ticket : name email number .. ect -->
                <div class="row well">
                <?php include("layouts/profileTicket.php"); ?>
                </div>
                     <!-- load sidebar Menu  -->
                    
                     <?php include("layouts/sidebar.php"); ?>
        </div>

    <div class="col-md-9 col-xs-12 ">
        <div class="container-fluid">
      
            <div class="col-md-offset-3 col-md-6 col-xs-12 well">
        

             
            <div class="card">
                <div class="card-header  text-white" style="padding:2% 2% 2% 2%;">
                    <div align="center">
                        <i class="fa fa-envelope"></i> &nbsp;<b>Contacter l'adminstrateur</b>
                    </div>
                    </div>
                    <br>
                    <div class="card-body">
                        <form id="sendMessage">
                            <div class="form-group">
                                <label for="object">Objet :</label>
                                <input type="text" class="form-control" name="objet" id="objet" placeholder="Objet de contact">

                            </div>
                            <div class="form-group">
                                <label for="message">Message :</label>
                                <textarea  class="form-control" name="message" id="message" placeholder="Message"></textarea>
                            <?php 
                                $query = "SELECT * FROM `administration` WHERE `departement`=?";
                                $sql = $pdo->prepare($query);
                                $sql->execute([$_SESSION['departement']]);
                                $user = "";
                                if($sql->rowCount()==1){
                                    $result = $sql->fetch(PDO::FETCH_ASSOC);
                                    $user = $result['username'];
                                }
                            ?>
                            </div>
                            <input type="hidden" name="user" id="user" value="<?php echo $user; ?>">
                            <center>
                            <button class="btn btn-large" >Envoyer</button>
                            </center>
                        </form>
                    </div>
               
            </div>
            



            </div>
            </div>

            

    </div>

    </div>

<script>
     $("#sendMessage").submit(function(){
       var objet = $("#objet").val();
        var contenu = $("#message").val();
        const type = "admin";
        var recepteur = $("#user").val();
       $.post("process/sendMessage.php",{objet:objet,recepteur:recepteur,contenu:contenu,type:type},function(data){
            window.alert(data);
    });
    $(this).trigger("reset");
    location.reload();
        return false;
    });
</script>


</body>
</html>