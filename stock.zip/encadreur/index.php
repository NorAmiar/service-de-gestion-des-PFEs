<!DOCTYPE html>
<html>
    <?  include("layouts/head.php"); ?>

    <body>
        <!-- load navbar layout -->
            <?php include("layouts/navbar.php"); ?>
        <br>

        <div class="container-fluid">
        
            
        <div class="col-md-3 col-xs-12">
            <div class="row well">
              <!-- load profile ticket : name email number .. ect -->
            <?php include("layouts/profileTicket.php"); ?>
            </div>
        
              
              
                <?php include("layouts/sidebar.php"); ?>
        </div>
        
          
            <div class="col-md-9 col-xs-12">
                <div class="container-fluid ">
                <div class="row  ">
         
                    <div align="center">
                        <h2> <b> Bienvenue Dans Votre Espace</b></h2>
                        <p>igbiuiubni</p>
                    </div>
                
                </div>
             
                <div class="row  ">
                    <div align="center">
                        <h2> <b> Notifications : </b></h2>
                    </div>
                </div>
            </div>
            </div>
       
      
           
                   <!-- load sidebar Menu  -->
                    
                  
                    
              
       
          
                <script>
                    function getCookie(name) {
                            var value = "; " + document.cookie;
                            var parts = value.split("; " + name + "=");
                            if (parts.length == 2) return parts.pop().split(";").shift();
                            }
                   x = getCookie("lang");
                  
    $(document).ready(function(){
      
        if(x=="fr"){
            $.MultiLanguage('language.json','fr');
       }else if(x=="en"){
        $.MultiLanguage('language.json','en');
       }else if(x=="ar"){
        $.MultiLanguage('language.json','ar');
       }
    });
</script>
          
    </body>
    </html>