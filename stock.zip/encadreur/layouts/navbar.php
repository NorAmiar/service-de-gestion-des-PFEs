<nav class="navbar navbar-inverse" >
  <div class="container-fluid">
    <div class="navbar-header" style="text-align:center;">
      <a class="navbar-brand" href="index.php">ESPACE ENCADREUR</a>
    </div>

    <ul class="nav navbar-nav navbar-right">
    <li><a href="deconnexion.php">Déconnexion</a></li>
   </ul>


  </div>
 
</nav>
