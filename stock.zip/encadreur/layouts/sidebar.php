
  <!-- <div class="col-md-3 col-xs-12 "> -->
  <div class="row">

  <div class="container-fluid" >
        <div class="row">

        <div class="col-md-6 col-xs-12">
        <a href="deposerSujet.php" > <div class="w3-card-4 card1" >
                <div align="center">
                    <b><span class="glyphicon glyphicon-import"></span><br> Déposer des sujets</b><br><br>
                </div>
            </div></a><br>
            </div>
            <div class="col-md-6 col-xs-12">
            <a href="mesSujets.php" ><div class="w3-card-4 card2" >
                <div align="center">
                   <b><span class="glyphicon glyphicon-pencil"></span><br> Liste Des Choix</b><br><br>
                </div>
            </div></a>
            </div>
        </div>
        <br>
        <div class="row">

<div class="col-md-6 col-xs-12">
<a href="mesEtudiants.php" > <div class="w3-card-4 card3" >
        <div align="center">
            <b><span class="glyphicon glyphicon-import"></span><br> Mes Etudiants Encadrer</b><br>
        </div>
    </div></a>
    </div>
    <div class="col-md-6 col-xs-12">
    <a href="mesRdv.php" ><div class="w3-card-4 card4" >
        <div align="center">
           <b><span class="glyphicon glyphicon-pencil"></span> <br> Mes Rendez-Vous</b><br><br>
        </div>
    </div></a>
    </div>
</div>
<br>
<div class="row">

<div class="col-md-6 col-xs-12">
<a href="messagerie.php" > <div class="w3-card-4 card5" >
        <div align="center">
            <b><span class="glyphicon glyphicon-import"></span><br> Gestion de Messagerie</b><br>
        </div>
    </div></a>
    </div>
    <div class="col-md-6 col-xs-12">
    <a href="contact.php" ><div class="w3-card-4 card6" >
        <div align="center">
           <b><span class="glyphicon glyphicon-pencil"></span><br> Contacter l'Administration</b>
        </div>
    </div></a>
    </div>
</div>
<br>


</div>

                 </div>