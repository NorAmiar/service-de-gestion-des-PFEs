<?php 
    include("../config/db.php");
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
	    <title>Gestion des PFEs | Université 8 Mai 1945 Guelma</title>
	    <meta charset="UTF-8">  
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        <link rel="stylesheet" href="../static/css/w3.css">
        <link rel="stylesheet" href="../static/css/admin.css">
        <link href="../static/css/bootstrap.min.css" rel="stylesheet">
        <script src="../static/js/jquery.js" ></script>
        <script src="../static/js/datatables.min.js"></script>
        <script src="../static/js/multi.min.js" ></script>
        <script src="../static/js/bootstrap.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
        <script src="../static/js/bar2.js"></script>
    
        <link rel="stylesheet" href="../static/css/datatables.min.css">
     
    </head>
    <?php 
       if(isset($_SESSION['role']) && $_SESSION['role']=="admin"){
    
    ?>
    <body style="background-color:#e5ebf0;">
    <?php include("layouts/navbar.php"); ?>
        <br>

        <div class="container-fluid">
        <?php include("layouts/sidebar.php"); ?>
        <div class="col-md-9 col-xs-12" >
                <div class="row">
                <?php 
                    $query = "SELECT * FROM `etudiant` WHERE `departement`=?";
                    $sql = $pdo->prepare($query);
                    $sql->execute([$_SESSION['departement']]);
                    $nombreEtudiants = $sql->rowCount();
                    $query = "SELECT * FROM `etudiant` WHERE `departement`=? AND `id_compte` <> ?";
                    $sql = $pdo->prepare($query);
                    $sql->execute([$_SESSION['departement'],""]);
                    $avecCompte = $sql->rowCount();
                    $sansCompte = $nombreEtudiants - $avecCompte;

                    $query = "SELECT * FROM `compte_etudiants` WHERE `sujet` <> ? AND `departement`=?";
                    $sql = $pdo->prepare($query);
                    $sql->execute(["",$_SESSION['departement']]);
                    $avecSujet = 0;
                    if($sql->rowCount()>0){
                        while($result = $sql->fetch(PDO::FETCH_ASSOC)){
                            if($result['typeC']=="Monome"){
                                $avecSujet++;
                            }else{
                                if($result['typeC']=="Binome"){
                                    $avecSujet+=2;
                                }else{
                                    if($result['typeC']=="Trinome"){
                                        $avecSujet+=3;
                                    }
                                }
                            }
                        }
                    }
                    $sansSujet = $nombreEtudiants - $avecSujet

                ?>
                <div class="chart-container col-md-6">
                <canvas id="myChart4"></canvas>
                <br>
                <center><b>Nombre total des etudiants : <?php echo $nombreEtudiants ?></b></center>

            </div>
            <input type="hidden" id="sansCompte" value="<?php echo $sansCompte; ?>">
            <input type="hidden" id="avecCompte" value="<?php echo $avecCompte; ?>">

            <input type="hidden" id="avecSujet" value="<?php echo $avecSujet; ?>">
            <input type="hidden" id="sansSujet" value="<?php echo $sansSujet; ?>">
            
            <div class="chart-container col-md-6">
                <canvas id="myChart5"></canvas>
                <br>
                <center><b>Nombre total des etudiants : <?php echo $nombreEtudiants ?></b></center>
            </div>
            
            </div>
            <br><br>
            <ul class="nav nav-tabs">
                    <li class="active"><a data-toggle="tab" href="#etudiantAvecCompte">Etudiants avec Compte</a></li>
                    <li><a data-toggle="tab" href="#etudiantSansCompte">Etudiants sans Compte</a></li>
                    <li><a data-toggle="tab" href="#etudiantAvecSujet">Comptes avec Sujet</a></li>
                    <li><a data-toggle="tab" href="#etudiantSansSujet">Comptes sans Sujet</a></li>
                    
                </ul>
                <div class="tab-content">
                    <div id="etudiantAvecCompte" class="tab-pane fade in active">
                    <div class="table-responsive ">
                 <table id="example" class="table table-striped table-bordered" style="width:100%">
                     <thead>
                <tr>
                    <th>Matricule</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>email</th>
                    <th>Moyenne</th>
                    <th>Niveau</th>
                    <th>PIN</th>
                  
                 

            
                </tr>
        </thead>
        <tbody>

        <?php 
          $departement = $_SESSION['departement'];
          $query = "SELECT * FROM `etudiant` WHERE `departement`=? AND `id_compte` <> ?";
          $sql = $pdo->prepare($query);
          $sql->execute([$departement,""]);
          
          if($sql->rowCount()>0){
              
              while($result = $sql->fetch(PDO::FETCH_ASSOC)){
        
        ?>



            <tr>
                <td><?php echo $result['matricule'];?> </td>
                <td><?php echo $result['nom']; ?></td>
                <td><?php echo $result['prenom']; ?></td>
                <td><?php echo $result['email']; ?></td>
                <td><?php echo $result['moyenne_e']; ?></td>
                <td><?php echo $result['niveau']; ?></td>
                <td><?php echo $result['pin']; ?></td>
               
            </tr>
            <?php   
                    }
                }
        ?>
        
        </tbody>
  
    </table>
        </div>
                    </div>
                    <div id="etudiantSansCompte" class="tab-pane fade">
                    <div class="table-responsive ">
                 <table id="example2" class="table table-striped table-bordered" style="width:100%">
                     <thead>
                <tr>
                    <th>Matricule</th>
                    <th>Nom</th>
                    <th>Prénom</th>
                    <th>email</th>
                    <th>Moyenne</th>
                    <th>Niveau</th>
                    <th>PIN</th>
                  
                 

            
                </tr>
        </thead>
        <tbody>

        <?php 
          $departement = $_SESSION['departement'];
          $query = "SELECT * FROM `etudiant` WHERE 1 EXCEPT SELECT * FROM etudiant WHERE id_compte <> ''";
          $sql = $pdo->prepare($query);
          $sql->execute([$departement,""]);
          
          if($sql->rowCount()>0){
              
              while($result = $sql->fetch(PDO::FETCH_ASSOC)){
        
        ?>



            <tr>
                <td><?php echo $result['matricule'];?> </td>
                <td><?php echo $result['nom']; ?></td>
                <td><?php echo $result['prenom']; ?></td>
                <td><?php echo $result['email']; ?></td>
                <td><?php echo $result['moyenne_e']; ?></td>
                <td><?php echo $result['niveau']; ?></td>
                <td><?php echo $result['pin']; ?></td>
               
            </tr>
            <?php   
                    }
                }
        ?>
        
        </tbody>
  
    </table>
        </div>
                    </div>
                    <div id="etudiantAvecSujet" class="tab-pane fade">
                    <div class="table-responsive ">
                 <table id="example3" class="table table-striped table-bordered" style="width:100%">
                     <thead>
                <tr>
                    <th>ID</th>
                    <th>Pseudo</th>
                    <th>Sujet</th>
                    <th>Moyenne</th>
                    <th>Niveau</th>
                    <th>Type De Compte</th>
            
                </tr>
        </thead>
        <tbody>
        <?php 
            $query = "SELECT * FROM `compte_etudiants` WHERE `departement`=? AND sujet <> ?";
            $sql = $pdo->prepare($query);
            $sql->execute([$departement,""]);
            
            if($sql->rowCount()>0){
                
                while($result = $sql->fetch(PDO::FETCH_ASSOC)){
                   $json = json_encode($result);
                    
        ?>
            <tr>
                <td><?php echo $result['idCompte'];?> </td>
                <td><a href="profile.php?user=<?php echo $result['user']; ?>"><?php echo $result['user']; ?></a> </td>
                <td><?php echo $result['sujet']; ?></td>
                <td><?php echo $result['moyenne_compte']; ?></td>
                <td><?php echo $result['niveau']; ?></td>
                <td><?php echo $result['typeC'] ?></td>
               
            </tr>
        <?php 
        
    }
}
        ?>
        </tbody>
       
    </table>

        </div>
                    </div>
                    <div id="etudiantSansSujet" class="tab-pane fade">
                    <div class="table-responsive ">
                 <table id="example4" class="table table-striped table-bordered" style="width:100%">
                     <thead>
                <tr>
                    <th>ID</th>
                    <th>Pseudo</th>
                    <th>Moyenne</th>
                    <th>Niveau</th>
                    <th>Type De Compte</th>
            
                </tr>
        </thead>
        <tbody>
        <?php 
            $departement = $_SESSION['departement'];
            $query = "SELECT * FROM `compte_etudiants` WHERE `departement`=? AND sujet = ?";
            $sql = $pdo->prepare($query);
            $sql->execute([$departement,""]);
            
            if($sql->rowCount()>0){
                
                while($result = $sql->fetch(PDO::FETCH_ASSOC)){
                   $json = json_encode($result);
                    
        ?>
            <tr>
                <td><?php echo $result['idCompte'];?> </td>
                <td><a href="profile.php?user=<?php echo $result['user']; ?>"><?php echo $result['user']; ?></a> </td>
                <td><?php echo $result['moyenne_compte']; ?></td>
                <td><?php echo $result['niveau']; ?></td>
                <td><?php echo $result['typeC'] ?></td>
                
            </tr>
        <?php 
        
    }
}
        ?>
        </tbody>
       
    </table>

        </div>
                    </div>
                </div>

        </div>
        </div>
     
        <script>
    $(document).ready(function() {
    $('#example').DataTable();
    $('#example2').DataTable();
    $('#example3').DataTable();
    $('#example4').DataTable();
} );
var sansCompte = $("#sansCompte").val();
var avecCompte = $("#avecCompte").val();
var sansSujet = $("#sansSujet").val();
var avecSujet = $("#avecSujet").val();
i = [sansCompte,avecCompte];
f = [sansSujet,avecSujet]; 
</script>
    </body>
    <?php 
     }else{
         
    
    ?>
<script>
    window.alert("Something Wrong .. ? ");
    document.location.href = "../index.php";
</script>
        <?php 
        
     }
        ?>
    </html>