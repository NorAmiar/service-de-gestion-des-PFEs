<div class="col-md-3 col-xs-12 " >
    <div class="container-fluid" >
        <div class="row">

        <div class="col-md-6 col-xs-12">
        <a href="gestionEtudiant.php" > <div class="w3-card-4 card1" >
                <div align="center">
                    <b><span class="glyphicon glyphicon-import"></span><br> <b id="gestEtud"> Gestion comptes Etudiants</b></b><br>
                </div>
            </div></a><br>
            </div>
            <div class="col-md-6 col-xs-12">
            <a href="gestionEncadreur.php" ><div class="w3-card-4 card2" >
                <div align="center">
                   <b><span class="glyphicon glyphicon-pencil"></span><br> <b id="gestEnc" >Gestion comptes Encadreur</b></b><br>
                </div>
            </div></a>
            </div>
        </div>
        <br>
        
        <div class="row">
        <div class="col-md-6 col-xs-12">
            <a href="gestionSujets.php" ><div class="w3-card-4 card3" >
                <div align="center">
                    <b><span class="glyphicon glyphicon-calendar"></span><br><b id="gestSuj"> Gestion des sujets</b></b> 
                </div>
            </div></a><br>
            </div>
            <div class="col-md-6 col-xs-12">
            <a href="rdvHis.php" ><div class="w3-card-4 card4" >
                <div align="center">
                    <b> <span class="glyphicon glyphicon-envelope"></span><br> <b id="his">Historique</b></b><br>
                   
                </div>
            </div></a>
            </div>


        </div>
        
        <br>
        <div class="row">
        <div class="col-md-6 col-xs-12">
            <a href="stats.php" ><div class="w3-card-4 card5" >
                <div align="center">
                    <b><span class="glyphicon glyphicon-stats"></span><br><b id="stat"> Statistique  </b></b>
                </div>
            </div></a><br>
            </div>
            <div class="col-md-6 col-xs-12">
            <a href="messagerie.php" ><div class="w3-card-4 card6" >
                <div align="center">
                    <b> <span class="glyphicon glyphicon-envelope"></span><br><b id="gestMsg"> Gestion de la Messagerie</b></b><br>
                   
                </div>
            </div></a>
            </div>


        </div>
        
        <br>

    </div>
</div>