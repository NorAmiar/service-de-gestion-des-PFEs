<html>
<head>
<title>translation</title>
<script src="../static/js/jquery.js" ></script>
        <script src="../static/js/multi.min.js" ></script>
        <script src="../static/js/bootstrap.min.js"></script>
</head>
<body>
    
   <label for="">id</label>
   <input type="text" id="id">
    <label for="">eng</label>
        <input type="text" id="eng">
        <label for="">fr</label>
        <input type="text" id="fr">
        <label for="">ar</label>
        <input type="text" id="ar">
        <button type="button" id="btn">add</button>
    <button type="button" id="exp">Export</button>
    <br><br>
    <textarea name="log" id="log" cols="30" rows="10"></textarea>
   <script>
   fr = Array();
   eng = Array();
   ar = Array();
    $(document).ready(function(){
        
    });
    $("#btn").click(function(){
        id = $("#id").val();
        v1 = $("#eng").val();
        v2 = $("#fr").val();
        v3 = $("#ar").val();
        eng.push('"#'+id+'":'+'"'+v1+'"');
        fr.push('"#'+id+'":'+'"'+v2+'"');
        ar.push('"#'+id+'":'+'"'+v3+'"');
         $("#id").val("");
        $("#eng").val("");
         $("#fr").val("");
        $("#ar").val("");
    });

    $("#exp").click(function(){
        $.post("export.php",{fr:fr,eng:eng,ar:ar},function(data){
            window.alert(data);
            $("#log").val(data);
            console.log(data);
        });
    });
   </script>
</body>
</html>