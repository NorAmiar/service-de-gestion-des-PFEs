<!DOCTYPE html>
<html>
    <head>
	    <title>Gestion des PFEs | Université 8 Mai 1945 Guelma</title>
	    <meta charset="UTF-8">  
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        <link rel="stylesheet" href="../static/css/w3.css">
        <link rel="stylesheet" href="../static/css/admin.css">
        <link href="../static/css/bootstrap.min.css" rel="stylesheet">
        <script src="../static/js/jquery.js" ></script>
        <script src="../static/js/multi.min.js" ></script>
        <script src="../static/js/bootstrap.min.js"></script>
    </head>
    <?php 
    session_start();
       if(isset($_SESSION['role']) && $_SESSION['role']=="admin"){
    
    ?>
    <body>
    <?php include("layouts/navbar.php"); ?>
        <br>



        <div class="container-fluid">
        <?php include("layouts/sidebar.php"); ?>
        <div class="col-md-9 col-xs-12">
            <h1><b>Statistiques </b></h1>
            <br>
            <div class="container">
            <ul class="nav nav-pills nav-stacked">
                <a href="sujets.php"><li style="  font-size:35px;"><span class="glyphicon glyphicon-list-alt"></span> Sujets</li></a>
                <a href="encadreurStats.php"><li style="font-size:35px;"><span class="glyphicon glyphicon-briefcase"></span> Encadreurs</li></a>
                <a href="comptes.php"><li style="font-size:35px;"><span class="glyphicon glyphicon-user"></span> Comptes</li></a>
                </ul>
            </div>
        </div>
       
    </div>

    </body>
    <?php 
     }else{
         
    
    ?>
<script>
    window.alert("Something Wrong .. ? ");
    document.location.href = "../index.php";
</script>
        <?php 
        
     }
        ?>
    </html>