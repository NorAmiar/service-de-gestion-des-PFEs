<?php  
    include("../config/db.php");
?>
<html>
<?php include("layouts/head.php"); ?>
<body>
    <?php include("layouts/navbar.php") ?>
    <div class="container-fluid">
    <div class="col-md-3 col-xs-12 ">
        <div class="row well">
        <?php include("layouts/profileTicket.php"); ?>
        </div>
        <?php include("layouts/sidebar.php"); ?>
        </div>
           
    <div class="col-md-9 col-xs-12 ">
        <div class="container-fluid well">
            <h2><b>Liste Des Choix : </b></h2>
            <?php 
                $query = "SELECT * FROM `departement` WHERE `nom`=?";
                $sql = $pdo->prepare($query);
                $sql->execute([$_SESSION['departement']]);
                if($sql->rowCount()==1){
                    $result = $sql->fetch(PDO::FETCH_ASSOC);
                    if($result['choixSujet']==1){
            ?>
        <div class="table-responsive">
        <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>ID</th>
                <th>Sujet</th>
                <th>Date De Choix</th>
                <th>Reponse</th>
                <th>Action</th>
        
            </tr>
        </thead>
        <tbody>
        <?php 
            $query = "SELECT * FROM `choix` WHERE `departement`=? AND `user`=? ORDER BY `priority` ASC";
            $sql = $pdo->prepare($query);
            $sql->execute([$_SESSION['departement'],$_SESSION['user']]);
            if($sql->rowCount()>0){
                while($result = $sql->fetch(PDO::FETCH_ASSOC)){
                    $query2 = "SELECT * FROM `sujet` WHERE `titre`=? ";
                    $sql2 = $pdo->prepare($query2);
                    $sql2->execute([$result['sujet']]);
                    $result2 = $sql2->fetch(PDO::FETCH_ASSOC);
                    
        ?>
            <tr>
                <td><?php echo $result['id']; ?></td>
                <td><a href="theme.php?id=<?php echo $result2['id']; ?>"><?php echo $result['sujet']; ?></a></td>
                <td><?php echo $result['dateChoix']; ?></td>
                <td><?php  
                    if($result['etat']==0){
                        echo "Pas de Reponse";
                    }else{
                        echo "Confirmé par l'encadreur";
                    }
                ?></td>
                <td><?php  
                    if($result['etat']==1){
                        ?>
                        <button onclick="confirmer(<?php echo $result['id']; ?>)" >Confirmer</button>
                        <?php
                    }
                ?></td>
              
            </tr>
            <?php 

                    }
                }
            ?>
 
        </tbody>
    </table>

        </div>
        <?php 
                    }else{
                        echo "Session de choix des sujets est fermé";
                    }
                }
        ?>
                </div>

    </div>
  

    </div>

<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );

function confirmer(id){
    $.post("process/confirmChoix.php",{id:id},function(data){
        window.alert(data);
    });
    location.reload();
}
</script>
</body>
</html>