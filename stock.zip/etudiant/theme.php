<?php 
    include("../config/db.php");
    if(isset($_GET['id']) && $_GET['id']>=0){
        
 $id = $_GET['id'];
?>
<html>
<?php include("layouts/head.php"); ?>
<body>
    <?php include("layouts/navbar.php") ?>
    <div class="container-fluid">
    <div class="col-md-3 col-xs-12">
                <!-- load profile ticket : name email number .. ect -->
                <div class="row well">
                <?php include("layouts/profileTicket.php"); ?>
                </div>
                     <!-- load sidebar Menu  -->
                    
                     <?php include("layouts/sidebar.php"); ?>
        </div>
    <div class="col-md-9 col-xs-12 ">
        <div class="container-fluid">
            <?php  
                $query = "SELECT * FROM `sujet` WHERE `id`=?";
                $sql= $pdo->prepare($query);
                $sql->execute([$id]);
                if($sql->rowCount()==1){
                    
                $result = $sql->fetch(PDO::FETCH_ASSOC);
                $etat = $result['etat'];
                $encadreur = $result['encadreur'];
            ?>
        <center><h1><?php echo $result['titre'] ?></h1></center>
        <p><b>Encadreur : <a href="encadreur.php?user=<?php echo $result['encadreur'];?>"><?php echo $result['encadreur'];?></a>  </b> </p>  
        <p><b>Descreption : </b></p><br><center> <p><?php echo $result['contenu'];?></p></center>
        <p><b>Keywords : </b><?php echo $result['keywords'];?></p>
        <p><b>Environement : </b><?php echo $result['environement'];?></p>
        <p><b>Bibliographie : </b><?php echo $result['bibliographie'];?></p>
        <?php  if($result['valid']==0){
            ?>
            <p><b>Le theme n'est pas encore validé</b></p>
            <?php
        }else{
            if($result['valid']==1 && $result['etat']==1){
                $titre = $result['titre'];
                $query2 = "SELECT * FROM `compte_etudiants` WHERE `sujet`=?";
                $sql2 = $pdo->prepare($query2);
                $sql2->execute([$titre]);
                $result2 = $sql2->fetch(PDO::FETCH_ASSOC);

                
                ?> 
                
                 <p><b>Etudiant(s) : </b><a href="profile.php?user=<?php echo $result2['user']; ?>"><?php echo $result2['user']; ?></a></p>
                <p><b>Taux d'avancement :</b> <?php echo $result['tauxAvancement']; ?> </p>
                 <?php 
            }else{
                if($result['valid']==1 && $result['etat']==0){
                    ?> 
                    <p><b>Le theme n'est pas encore affecté</b></p>
                    <p><b>Nombre de fois choisi : </b> <?php echo $result['nb_choix']; ?> </p>
                    <?php
                }
            }
        } ?>
    
        <br><br><br>
        <?php  
        
    }else{
        echo "Sujet not found";
    }
        ?>
                </div>

    </div>

    </div>


</body>
</html>
<?php 


}
?>