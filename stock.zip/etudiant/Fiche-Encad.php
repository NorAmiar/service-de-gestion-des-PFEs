<?php
require('code128.php');

$pdf=new PDF_Code128();
$pdf->AddPage('L');
$pdf->SetFont('Arial','',10);

//A set

$ids= $_GET['idS'];
$nEt1= $_GET['ne1'];
$nEt2= $_GET['ne2'];

$nEnc= $_GET['nEnc'];
$pEnc= $_GET['pEnc'];
$titre= $_GET['titre'];
//$titre =iconv('utf-8','ASCII//IGNORE//TRANSLIT',$titre);

$titre = str_replace("é", 'e', $titre);
$titre = str_replace("è", 'e', $titre);

$type= $_GET['type'];

$nEt1c=substr("$nEt1", 0, 4);
$nEt2c=substr("$nEt2", 0, 4);
$nEncc=substr("$nEnc", 0, 4);
$typec=strtoupper(substr("$type", 0, 1));

$y=date("y");
$y2=date("y")+1;

$contenu= nl2br(" $typec-$ids [Enc: $nEncc] $nEt1c $nEt2c $y/$y2");






// draw jpeg image
$pdf->Image('images/fAttribution.png',0,0,300);

// restore full opacity
//$pdf->SetAlpha(1);


// draw jpeg image
$pdf->Image('images/fAttribution.png',0,0,300);

// restore full opacity
//$pdf->SetAlpha(1);
$pdf->Ln(60);
$pdf->SetX(250);
$pdf->SetFont('Times', 'B', 14);
$pdf->Cell(20,10,$type,1,0,'C');

// print name of supervisor
$pdf->SetFont('Times', 'B', 16);
$pdf->Text(80,111,$nEt1);
$pdf->Text(80,121.5,$nEt2);
$pdf->Text(113,132,$pEnc.' '.$nEnc);
$pdf->Text(55,143.5,$titre);

//$pdf->Text(113,152,$contenu);

//C set
$code=$contenu;
$pdf->Code128(160,90,$contenu,110,15);





$pdf->Output();
?>
